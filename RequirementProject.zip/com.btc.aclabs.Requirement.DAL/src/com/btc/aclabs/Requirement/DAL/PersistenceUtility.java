package com.btc.aclabs.Requirement.DAL;

import java.util.List;

public interface PersistenceUtility {

	public void create(Requirement r);

/*	public List read();*/

	public void remove(Requirement r);

	public void update(Requirement r);
	
	public List<Requirement> getAll();
	
	public Requirement getRequirementByID(int id);
}

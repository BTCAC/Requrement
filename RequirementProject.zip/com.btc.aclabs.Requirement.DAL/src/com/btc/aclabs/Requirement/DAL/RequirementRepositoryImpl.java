package com.btc.aclabs.Requirement.DAL;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.btc.aclabs.Requirement.BL.dmos.RequirementDMO;
import com.btc.aclabs.Requirement.BL.service.RequirementRepository;
import com.btc.aclabs.Requirement.BLimpl.dmos.RequirementDMOImpl;

@Component(immediate = true)
public class RequirementRepositoryImpl implements RequirementRepository {

	private PersistenceUtility persistenceUtilityService;

	@Override
	public void create(RequirementDMO r) {
		Requirement requirement = createEntity(r);
		persistenceUtilityService.create(requirement);

	}

	@Override
	public void remove(RequirementDMO r) {
		Requirement requirement = persistenceUtilityService.getRequirementByID(r.getID());
		persistenceUtilityService.remove(requirement);
	}

	@Override
	public void update(RequirementDMO r) {
		Requirement requirement = persistenceUtilityService.getRequirementByID(r.getID());
		persistenceUtilityService.update(requirement);
	}

	/*@Override
	public void read() {
		persistenceUtilityService.read();

	}*/

	@Reference
	public void setPersistenceUtility(PersistenceUtility persistenceUtilitySerivce) {
		this.persistenceUtilityService = persistenceUtilitySerivce;
	}

	public Requirement createEntity(RequirementDMO r) {
		Requirement requirement = null;
		try {
			requirement = new RequirementImpl(r.getName(), r.getShortDescription(), r.getLongDescription(),
					r.getCreationDate(), r.getModifyDate(), r.getCreator());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return requirement;
	}

	@Override
	public List<RequirementDMO> getAll() {

		List<RequirementDMO> requirementDMOs = new ArrayList<RequirementDMO>();
		List<Requirement> requirements = persistenceUtilityService.getAll();
		for (Requirement r : requirements) {
			RequirementDMO reqDMO = createDMO(r.getNameReq(), r.getShortDescriptionReq(),
					r.getLongDescriptionReq(), r.getCreationDate().toString(), r.getModifyDate().toString(), r.getCreatorReq());
			requirementDMOs.add(reqDMO);
		}
		return requirementDMOs;
	}

	@Override
	public RequirementDMO createDMO(String name, String shortDescription, String longDescription, String creationDate,
			String modifyDate, String creator) {
		
		return new RequirementDMOImpl(name, shortDescription, longDescription, creationDate, modifyDate, creator);
	}

}

package com.btc.aclabs.Requirement.BL.dmos;


public interface RequirementDMO {

	
	public String getName() ;


	public void setName(String name);


	public String getShortDescription();


	public void setShortDescription(String shortDescription) ;


	public String getLongDescription() ;


	public void setLongDescription(String longDescription);


	public String getCreationDate();


	public void setCreationDate(String creationDate);


	public String getModifyDate();


	public void setModifyDate(String modifyDate);
	


	public String getCreator() ;


	public void setCreator(String creator);
	
	public int getID();

}

package com.btc.aclabs.Requirement.BL.service;

import java.util.List;

import com.btc.aclabs.Requirement.BL.dmos.RequirementDMO;

public interface RequirementRepository {

	void create(RequirementDMO r);

	void remove(RequirementDMO r);

	void update(RequirementDMO r);

	/*void read();*/
	
	List<RequirementDMO> getAll();
	
	RequirementDMO createDMO(String name, String shortDescription, String longDescription, String creationDate,
			String modifyDate,String creator);

}

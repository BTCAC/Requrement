package com.btc.aclabs.requirement.ui.handlers;

import org.eclipse.e4.core.di.annotations.Execute;

public class ExportXML {

	@Execute

	public void execute() {
		System.out.println((this.getClass().getSimpleName() + " called"));
	}

}

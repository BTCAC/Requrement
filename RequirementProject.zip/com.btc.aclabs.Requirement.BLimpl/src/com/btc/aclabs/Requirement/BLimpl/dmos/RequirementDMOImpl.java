package com.btc.aclabs.Requirement.BLimpl.dmos;

import com.btc.aclabs.Requirement.BL.dmos.RequirementDMO;

public class RequirementDMOImpl implements RequirementDMO{
	
	private String name;
	private String shortDescription;
	private String longDescription;
	private String creationDate;
	private String modifyDate;
	private String creator;
	private int ID;
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getShortDescription() {
		return shortDescription;
	}


	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}


	public String getLongDescription() {
		return longDescription;
	}


	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}


	public String getCreationDate() {
		return creationDate;
	}


	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}


	public String getModifyDate() {
		return modifyDate;
	}


	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}


	public String getCreator() {
		return this.creator;
	}


	public void setCreator(String creator) {
		this.creator = creator;
	}

/**
 * 
 * @param name requirement name
 * @param shortDescription short description
 * @param longDescription longDescription
 * @param creationDate creationDate
 * @param modifyDate modifyDate
 * @param creator creator
 */
	public RequirementDMOImpl(String name, String shortDescription, String longDescription, String creationDate,
			String modifyDate, String creator) {
		this.name=name;
		this.shortDescription=shortDescription;
		this.longDescription=longDescription;
		this.creationDate=creationDate;
		this.modifyDate=modifyDate;
		this.creator=creator;
	}


@Override
public int getID() {
	return this.ID;
}

}

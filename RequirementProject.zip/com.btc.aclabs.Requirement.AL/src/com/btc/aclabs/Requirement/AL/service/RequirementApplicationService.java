package com.btc.aclabs.Requirement.AL.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.btc.aclabs.Requirement.AL.dto.RequirementDto;
import com.btc.aclabs.Requirement.BL.dmos.RequirementDMO;

public interface RequirementApplicationService {

	void create(String name, String shortDescription, String longDescription, String creationDate, String modifyDate,String creator) throws ParseException;

	List<RequirementDto> getAll();

	String toString();
	
	public RequirementDto createDTO(String name, String shortDescription, String longDescription, String creationDate, String modifyDate,String creator);

	/*void ExportJson(ArrayList<RequirementDMO> req, String cale);*/

}

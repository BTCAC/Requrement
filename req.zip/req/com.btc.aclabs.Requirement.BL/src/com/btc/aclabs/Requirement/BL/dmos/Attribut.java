package com.btc.aclabs.Requirement.BL.dmos;

public interface Attribut {
	 boolean equals(Object o);
	 String toString();
	 String getDescription();
	 void changeDescription(String description);
	 String getType();
}

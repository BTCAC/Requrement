package com.btc.aclabs.Requirement.BL.dmos;

import java.util.ArrayList;
import java.util.Date;

public interface Requirement {

	String toString();
	String getNameReq();
	String getShortDescriptionReq();
	String getLongDescriptionReq();
	String getCreatorReq();
	ArrayList<Attribut> getAttributeList();
	Date getModifyDate();
	Date getCreationDate();
	 
}
	
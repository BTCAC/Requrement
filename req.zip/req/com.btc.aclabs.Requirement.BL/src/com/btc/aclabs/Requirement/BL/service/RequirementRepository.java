package com.btc.aclabs.Requirement.BL.service;

import com.btc.aclabs.Requirement.BL.dmos.Requirement;

public interface RequirementRepository {
	
	 void create(Requirement r);
	 void remove(Requirement r);
	 void upppDate(Requirement r);
	 void read();
	

}

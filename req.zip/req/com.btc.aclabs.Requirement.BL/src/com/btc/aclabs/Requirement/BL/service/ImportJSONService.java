package com.btc.aclabs.Requirement.BL.service;

public interface ImportJSONService {
	void ImportJSON(String path);

}

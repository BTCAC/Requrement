package com.btc.aclabs.Requirement.BL.service;

import java.text.ParseException;

import com.btc.aclabs.Requirement.BL.dmos.Requirement;

public interface RequirementService {
	void addRequirement(Requirement r);
	void addAttributes(String type,String description);
	void displayAll();
	void displaydetails(Object o);
	String toString();
	void create(String name,String shortDescription,String longDescription,String creationDate,String modifyDate,String creator) throws ParseException;
		
	

}

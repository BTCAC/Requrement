package com.btc.aclabs.Requirement.ALimpl.internal.service;

import java.text.ParseException;
import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.btc.aclabs.Requirement.AL.dto.RequirementDto;
import com.btc.aclabs.Requirement.AL.service.RequirementApplicationService;
import com.btc.aclabs.Requirement.BL.service.ExportJSONService;
import com.btc.aclabs.Requirement.BL.service.ImportJSONService;
import com.btc.aclabs.Requirement.BL.service.RequirementService;

@Component(immediate = true)
public class RequirementApplicationInternalService  implements RequirementApplicationService {

	private RequirementService req;
	private ExportJSONService eJS;
	private ImportJSONService iJS;
	
	@Reference
	public void setR(RequirementService req1){
		req = req1;
	}
	
	@Reference
	public void setEJS(ExportJSONService ejs)
	{
		this.eJS=ejs;
	}
	
	@Reference
	public void setIJS(ImportJSONService ijs)
	{
		this.iJS=ijs;
	}
	
	public void create(String name,String shortDescription,String longDescription,String creationDate,String modifyDate,String creator) throws ParseException
	 {	req.create(name, shortDescription, longDescription, creationDate, modifyDate, creator);
		System.out.print("done");
	
	}
	
	public List<RequirementDto> getAll() {
		
		req.displayAll();
		return null;
	}
	
	public String toString(){
		return req.toString();
	}
	
	public void ExportJson(String path) {
	
		eJS.exportJSON(path);
	}

	public void ImportJSON(String path){
		 iJS.ImportJSON(path);
	};
	
	
}

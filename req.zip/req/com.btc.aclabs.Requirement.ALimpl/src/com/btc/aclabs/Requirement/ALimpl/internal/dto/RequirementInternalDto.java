package com.btc.aclabs.Requirement.ALimpl.internal.dto;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


import com.btc.aclabs.Requirement.AL.dto.RequirementDto;
import com.btc.aclabs.Requirement.BL.dmos.Attribut;
import com.btc.aclabs.Requirement.BL.dmos.Requirement;

public class RequirementInternalDto implements RequirementDto {

	private String creator;
	private String name;
	private String shortDescription;
	private String longDescription;
	private SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
	private Date creationDate=new Date();
	private Date modifyDate=new Date();
	private ArrayList <Attribut> attributeList;
	private ArrayList <Requirement> requirementList;
	
	public RequirementInternalDto(String name,String shortDescription,String longDescription,String creationDate,String modifyDate,String creator) throws ParseException{
		this.name=name;
		this.shortDescription=shortDescription;
		this.longDescription=longDescription;
		this.creationDate = sdf.parse(creationDate);
		this.modifyDate = sdf.parse(modifyDate);
		this.creator=creator;
	}
	 
	
	public String getName() {
	
		return this.name;
	}
	 
	public String getshortDescription() {
		
		return this.shortDescription;
	}
	
	public String getlongDescription() {
	
		return this.longDescription;
	}

	
	public Date getcreationDate() {
	
		return this.creationDate;
	}
	
	public Date getmodifyDate() {
	
		return this.modifyDate;
	}
	
	public String getCreator() {
		
		return this.creator;
	}

	public ArrayList<Attribut> getAttributeList() {
		
		return this.attributeList;
	}
	
	public ArrayList<Requirement> getRequirementList() {
	
		return this.requirementList;
	}
	
	
}

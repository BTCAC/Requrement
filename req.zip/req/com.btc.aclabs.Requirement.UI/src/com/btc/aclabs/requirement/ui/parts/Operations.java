package com.btc.aclabs.requirement.ui.parts;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import com.btc.aclabs.Requirement.AL.service.RequirementApplicationService;


public class Operations {
	private Display display;
	
	@Inject
	private RequirementApplicationService requirement;
	
	@PostConstruct
	
	public void createOper( Composite parent){
		  
	// CALENDAR PT UTILIZATOR	
		  	
       parent.setLayout(new GridLayout(2, false));

       DateTime calendar = new DateTime(parent, SWT.CALENDAR);
       DateTime time = new DateTime(parent, SWT.TIME);
       
    //Campuri pt introducerea datelor Requirementului        
        
        Label lablename = new Label(parent, SWT.None);
        lablename.setText("Name : ");
        Text textname = new Text(parent, SWT.BORDER);
                
        Label lableshortDescription = new Label(parent, SWT.NONE);
        lableshortDescription.setText("Short Description : ");
        Text textshortDescription = new Text(parent, SWT.BORDER);
        
        Label lablelongDescription = new Label(parent, SWT.NONE);
        lablelongDescription.setText("Long description : ");
        Text textlongDescription = new Text(parent, SWT.BORDER);
        
        Label lableattribute = new Label(parent, SWT.NONE);
        lableattribute.setText("Attribute :");
        //Label something = new Label(parent,SWT.NONE);
        Button attrib = new Button(parent,SWT.BORDER);
        attrib.setText("Add attribute");
        
        Label lablenAtt = new Label(parent,SWT.NONE);
        lablenAtt.setText("Attribute name : " );
        Text textatributte = new Text(parent, SWT.BORDER);
        
        Label labelnAttdescript = new Label(parent,SWT.NONE);
        labelnAttdescript.setText("Attribute description : ");
        Text attdescript = new Text(parent,SWT.BORDER);
        
        
  
        //butoane de actiune 
        
        Button button1 = new Button(parent, SWT.BORDER_SOLID);
		button1.setText("Add requirement");
		button1.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
					requirement.create(textname.getText(), textshortDescription.getText(), textlongDescription.getText(), sdf.format(System.currentTimeMillis()), sdf.format(System.currentTimeMillis()), "roxi");
					textname.setText(" ");
					textlongDescription.setText(" ");
					textshortDescription.setText(" ");
				} catch (ParseException e1) {
					
					e1.printStackTrace();
				}
				textname.setText("");
				textlongDescription.setText("");
				textshortDescription.setText("");
				textatributte.setText("");
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		
		Button button2 = new Button(parent,SWT.BORDER_SOLID);
		button2.setText("Edit");
		button2.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
       		
		attrib.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
 
	    
	    while (!parent.isDisposed()) {
	    	if (!display.readAndDispatch())
	            display.sleep();
	        }
	        // tear down the SWT window
	    display.dispose(); 
			
			
	        
	}}
 
	
	
    




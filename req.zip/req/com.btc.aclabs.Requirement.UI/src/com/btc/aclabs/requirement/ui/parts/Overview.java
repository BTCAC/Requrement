package com.btc.aclabs.requirement.ui.parts;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.btc.aclabs.Requirement.AL.service.RequirementApplicationService;



public class Overview {

		Display display;
		
		@Inject
		private RequirementApplicationService requirement;
		
		@PostConstruct
		
		public void createView(Composite parent){
		
			parent.setLayout(new GridLayout(2, false));
			
		
			Button button1 = new Button(parent,SWT.CHECK);
			button1.setText("Display All");
			
			Button button2  = new Button(parent,SWT.CHECK);
			button2.setText("Display one Requirement");

			button1.addSelectionListener(new SelectionListener() {
				
				@Override
				public void widgetSelected(SelectionEvent e) {
					// TODO Auto-generated method stub
					Text textal = new Text(parent,SWT.BORDER);
					
					if(button1.getSelection()){
					//Text textal = new Text(parent,SWT.BORDER);
					textal.setLocation(10, 30);
					textal.setSize(250, 400);
					String s =requirement.toString()+"\n";
					textal.setText(s);
					}
					else
						textal.setVisible(false);
						
				}
				
				@Override
				public void widgetDefaultSelected(SelectionEvent e) {
					// TODO Auto-generated method stub
					
				}
			});
			
			
			button2.addSelectionListener(new SelectionListener() {
				
				@Override
				public void widgetSelected(SelectionEvent e) {
					// TODO Auto-generated method stub
					
					Label lablename = new Label(parent, SWT.None);
			        lablename.setText("Name : ");
			        Text textname = new Text(parent, SWT.BORDER);
			        System.out.println("da");
				}
				
				@Override
				public void widgetDefaultSelected(SelectionEvent e) {
					// TODO Auto-generated method stub
					
				}
			});
			
			
		    while (!parent.isDisposed()) {
		        if (!display.readAndDispatch()) display.sleep();
		    }
		    display.dispose();
		}

		}

    
package com.btc.aclabs.Requirement.AL.service;

import java.text.ParseException;
import java.util.List;
import com.btc.aclabs.Requirement.AL.dto.RequirementDto;

public interface RequirementApplicationService {
	
	
	void create(String name,String shortDescription,String longDescription,String creationDate,String modifyDate,String creator) throws ParseException;
	List<RequirementDto> getAll();
	String toString();
	void ExportJson(String path);
	void ImportJSON(String path);

}

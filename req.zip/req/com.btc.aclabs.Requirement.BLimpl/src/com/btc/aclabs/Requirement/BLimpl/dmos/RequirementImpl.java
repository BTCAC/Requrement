package com.btc.aclabs.Requirement.BLimpl.dmos;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.btc.aclabs.Requirement.BL.dmos.Attribut;
import com.btc.aclabs.Requirement.BL.dmos.Requirement;

@Entity

public class RequirementImpl implements Requirement {
	@Id
	@GeneratedValue
	private String creator;
	@Basic
	private String name;
	@Basic
	private String shortDescription;
	@Basic
	private String longDescription;
	
	private SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
	@Basic
	private Date creationDate=new Date();
	@Basic
	private Date modifyDate=new Date();
	
	@OneToMany
	private ArrayList <Attribut> attributeList=new ArrayList<Attribut>();
	
	private ArrayList <Requirement> requirementList=new ArrayList<Requirement>();
	
	
	
	public RequirementImpl(String name,String shortDescription,String longDescription,String creationDate,String modifyDate,String creator) throws ParseException{
		this.name=name;
		this.shortDescription=shortDescription;
		this.longDescription=longDescription;
		this.creationDate = sdf.parse(creationDate);
		this.modifyDate = sdf.parse(modifyDate);
		this.creator=creator;
	}
	
	public String getNameReq() {
		// TODO Auto-generated method stub
		return this.name;
	}

	
	public String getShortDescriptionReq() {
		// TODO Auto-generated method stub
		return this.shortDescription;
	}

	@Override
	public String getLongDescriptionReq() {
		// TODO Auto-generated method stub
		return this.longDescription;
	}

	@Override
	public String getCreatorReq() {
		// TODO Auto-generated method stub
		return this.creator;
	}
	
	public ArrayList<Attribut> getAttributeList(){
		return attributeList;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	
	public Date getModifyDate() {
		return modifyDate;
	}


}

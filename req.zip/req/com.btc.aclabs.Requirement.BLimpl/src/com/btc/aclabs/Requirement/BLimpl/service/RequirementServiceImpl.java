package com.btc.aclabs.Requirement.BLimpl.service;

import java.text.ParseException;
import java.util.ArrayList;

import javax.inject.Inject;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.btc.aclabs.Requirement.BL.dmos.Attribut;
import com.btc.aclabs.Requirement.BL.dmos.Requirement;
import com.btc.aclabs.Requirement.BL.service.RequirementRepository;
import com.btc.aclabs.Requirement.BL.service.RequirementService;
import com.btc.aclabs.Requirement.BLimpl.dmos.AttributImpl;
import com.btc.aclabs.Requirement.BLimpl.dmos.RequirementImpl;

@Component(immediate = true)

public class RequirementServiceImpl implements RequirementService {

	/* @Inject */
	private RequirementRepository repo;

	private ArrayList<Requirement> requirementList = new ArrayList<Requirement>();
	private ArrayList<Attribut> attributesList = new ArrayList<Attribut>();

	public void addRequirement(Requirement r) {
		requirementList.add(r);
	}

	public String toString() {
		String s = "";
		for (Requirement req : requirementList) {
			s += req.getNameReq() + " " + req.getShortDescriptionReq() + " " + req.getLongDescriptionReq() + " "
					+ req.getCreatorReq() + " " + req.getCreationDate() + " " + req.getModifyDate() + "\n";
		}
		return s;
	}

	public void addAttributes(String type, String description) {

		Attribut Att = new AttributImpl(type, description);
		boolean t = false;
		for (Attribut it : attributesList) {
			if (it.equals(Att)) {
				t = true;
				it.changeDescription(description);
			}
		}
		if (t == false)
			attributesList.add(Att);
	}

	public void displayAll() {

		if (requirementList.isEmpty())
			System.out.println("We don't have Requirement");
		else {
			for (Requirement it : requirementList)
				System.out.println(it + "\n\n");
		}
	}

	public void displaydetails(Object o) {

		if (o instanceof Requirement)
			System.out.println(((Requirement) o));
	}

	public void create(String name, String shortDescription, String longDescription, String creationDate,
			String modifyDate, String creator) throws ParseException {

		Requirement req = new RequirementImpl(name, shortDescription, longDescription, creationDate, modifyDate,
				creator);
		requirementList.add(req);

		/*repo.create(req);*/

	}

	/*@Reference
	public void setRequirementRepositoryService(RequirementRepository requirementRepositoryService) {
		this.repo = requirementRepositoryService;
	}*/
}

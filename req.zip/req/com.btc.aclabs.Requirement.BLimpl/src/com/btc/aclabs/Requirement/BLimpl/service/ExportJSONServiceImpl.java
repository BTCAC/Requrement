package com.btc.aclabs.Requirement.BLimpl.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.osgi.service.component.annotations.Component;

import com.btc.aclabs.Requirement.BL.dmos.Attribut;
import com.btc.aclabs.Requirement.BL.dmos.Requirement;
import com.btc.aclabs.Requirement.BL.service.ExportJSONService;

@Component(immediate = true)
public class ExportJSONServiceImpl implements ExportJSONService {

	private ArrayList<Requirement> requirement;

	public ExportJSONServiceImpl(ArrayList<Requirement> req) {
		this.requirement = req;
	}
	/**
	 * @param path this method takes the whole path including the file name to be exported to
	 * */
	@SuppressWarnings("unchecked")
	public void exportJSON(String path) {
		try {
			FileOutputStream fos = new FileOutputStream(path);
			OutputStreamWriter osw = new OutputStreamWriter(fos);
			PrintWriter ow = new PrintWriter(osw);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
			JSONArray reqarray=new JSONArray();
			for (Requirement req : requirement) {
				JSONObject reqobject = new JSONObject();
				JSONArray atribut = new JSONArray();
				for (Attribut at : req.getAttributeList()) {
					JSONObject atr = new JSONObject();
					atr.put("type", at.getType());
					atr.put("description", at.getDescription());
					atribut.add(atr);
				}
				reqobject.put("attributes", atribut);
				reqobject.put("creator", req.getCreatorReq());
				reqobject.put("modifyDate", sdf.format(req.getModifyDate()));
				reqobject.put("creationDate", sdf.format(req.getCreationDate()));
				reqobject.put("longDescription", req.getLongDescriptionReq());
				reqobject.put("shortDescription", req.getShortDescriptionReq());
				reqobject.put("name", req.getNameReq());
				reqarray.add(reqobject);
			}
			JSONArray.writeJSONString(reqarray, ow);
			ow.close();
		} catch (IOException e) {
			// ignore
		}
	}
}

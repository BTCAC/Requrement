package com.btc.aclabs.requirement.ui.parts;

public class Overview {

	public Overview() {
		System.out.println("it workes" );
		
	}
}

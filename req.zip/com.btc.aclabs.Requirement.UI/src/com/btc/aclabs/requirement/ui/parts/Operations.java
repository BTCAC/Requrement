package com.btc.aclabs.requirement.ui.parts;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

import com.btc.aclabs.Requirement.AL.service.RequirementApplicationService;


public class Operations {
	private Text text;
	private Display display;
	
//	@Inject
	//private RequirementApplicationService req;
	
	
	@PostConstruct
	
	public void createOper( Composite parent){
		
	
	               
	// CALENDAR PT UTILIZATOR	
		  	
		
		final Shell shell = new Shell(display);
       // shell.setLayout(new RowLayout());
      //  GridLayout gridLayout = new GridLayout();
       
      //  gridLayout.numColumns = 1;
       // parent.setLayout(gridLayout);
        parent.setLayout(new GridLayout(1, false));

        
        DateTime calendar = new DateTime(parent, SWT.CALENDAR);
        DateTime time = new DateTime(parent, SWT.TIME);
       
       // shell.pack();

       Label label = new Label(shell, SWT.SEPARATOR | SWT.VERTICAL);
       		
       
	    final Tree tree = new Tree(parent, SWT.V_SCROLL);	 
	    tree.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
	    
	    
	    TreeItem item2 = new TreeItem(tree,SWT.NONE);
        item2.setText("Create New Requirement");
        
        TreeItem item = new TreeItem(tree, SWT.NONE);
        item.setText("Display");
            
        TreeItem subItem1 = new TreeItem(item, SWT.NONE);
        subItem1.setText("Display a single requirement");
            
        TreeItem subItem2 = new TreeItem(item, SWT.NONE);
        subItem2.setText("Display all requirements");
        
        TreeItem item3 = new TreeItem(tree, SWT.None);
        item3.setText("Edit a single requirement");
        
             
        
        
	    tree.pack();
	    Menu menu = new Menu(tree);
	    tree.setMenu(menu);
	    parent.pack();
	      	        
	   
	    while (!parent.isDisposed()) {
	    	if (!display.readAndDispatch())
	            display.sleep();
	        }
	        // tear down the SWT window
	    display.dispose(); 
			
			
	        
	}}
 
	
	
    




package com.btc.aclabs.requirement.ui.parts;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import com.btc.aclabs.Requirement.AL.service.RequirementApplicationService;


public class Operations {
	private Display display;
	@PostConstruct
	
	public void createOper( Composite parent){
		              
	// CALENDAR PT UTILIZATOR	
		  	
       parent.setLayout(new GridLayout(1, false));

       DateTime calendar = new DateTime(parent, SWT.CALENDAR);
       DateTime time = new DateTime(parent, SWT.TIME);
       
    //Campuri pt introducerea datelor Requirementului        
        
        Label lablename = new Label(parent, SWT.None);
        lablename.setText("Name : ");
        Text textname = new Text(parent, SWT.BORDER);
                
        Label lableshortDescription = new Label(parent, SWT.NONE);
        lableshortDescription.setText("Short Description : ");
        Text textshortDescription = new Text(parent, SWT.BORDER);
        
        Label lablelongDescription = new Label(parent, SWT.NONE);
        lablelongDescription.setText("Long description : ");
        Text textlongDescription = new Text(parent, SWT.BORDER);
        
        Label lableattribute = new Label(parent, SWT.NONE);
        lableattribute.setText("Attribute :");
        Text textatributte = new Text(parent, SWT.BORDER);
        
   //butoane de actiune nefunctionabile :(
        
        Button button1 = new Button(parent, SWT.BORDER_SOLID);
		button1.setText("Add requirement");
		button1.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
		
		// Nu stiu cum sa mai fac legaturile intre toate.. ceva nu imi iese 
				
		//RequirementApplicationService.add/create??
		//(new Requirement(textName.getText(),textDescription.getText(),
		//textshortDescription.getText(),textlongDescription.getText(),textattribute.getText()));
				textname.setText("");
				textlongDescription.setText("");
				textshortDescription.setText("");
				textatributte.setText("");
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		
		Button button2 = new Button(parent,SWT.BORDER_SOLID);
		button2.setText("Edit");
		button2.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
       		
		
  /*     meniul pom care nu merge si nu stiu de ce , si nu stiu nici cum sa pun  comenzi pe el 
   * din pacate
       
	    final Tree tree = new Tree(parent, SWT.V_SCROLL);	 
	    tree.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
	    	    
	    TreeItem item2 = new TreeItem(tree,SWT.NONE);
        item2.setText("Create New Requirement");
        
        TreeItem item = new TreeItem(tree, SWT.NONE);
        item.setText("Display");
            
        TreeItem subItem1 = new TreeItem(item, SWT.NONE);
        subItem1.setText("Display a single requirement");
            
        TreeItem subItem2 = new TreeItem(item, SWT.NONE);
        subItem2.setText("Display all requirements");
        
        TreeItem item3 = new TreeItem(tree, SWT.None);
        item3.setText("Edit a single requirement");
               
        
	    tree.pack();
	    Menu menu = new Menu(tree);
	    tree.setMenu(menu);
	    parent.pack();
	      	        
	   */
	    
	    
	    while (!parent.isDisposed()) {
	    	if (!display.readAndDispatch())
	            display.sleep();
	        }
	        // tear down the SWT window
	    display.dispose(); 
			
			
	        
	}}
 
	
	
    




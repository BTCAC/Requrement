package com.btc.aclabs.Requirement.AL.service;

public interface RequirementApplicationService {

}

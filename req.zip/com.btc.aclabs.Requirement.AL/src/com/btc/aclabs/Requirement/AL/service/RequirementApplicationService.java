package com.btc.aclabs.Requirement.AL.service;

import java.util.List;
import com.btc.aclabs.Requirement.AL.dto.RequirementDto;

public interface RequirementApplicationService {
	void create(String s);
	List<RequirementDto> getAll();

}

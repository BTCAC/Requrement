package com.btc.aclabs.Requirement.AL.dto;

public interface RequirementDto {

}

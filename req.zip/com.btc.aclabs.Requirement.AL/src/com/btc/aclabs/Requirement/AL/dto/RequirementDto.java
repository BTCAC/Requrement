package com.btc.aclabs.Requirement.AL.dto;

import java.util.ArrayList;
import java.util.Date;

import com.btc.aclabs.Requirement.BL.dmos.Attribut;
import com.btc.aclabs.Requirement.BL.dmos.Requirement;

public interface RequirementDto {
	 String getName();
	 String getshortDescription();
	 String getlongDescription();
	 Date getcreationDate();
	 Date getmodifyDate();
	 String getCreator();
	 ArrayList <Attribut> getAttributeList();
	 ArrayList <Requirement> getRequirementList();
}

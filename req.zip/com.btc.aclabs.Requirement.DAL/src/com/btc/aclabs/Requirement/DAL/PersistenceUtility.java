package com.btc.aclabs.Requirement.DAL;

import java.util.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.osgi.service.component.annotations.Component;

import com.btc.aclabs.Requirement.BL.dmos.Requirement;

@Component(immediate = true)
public class PersistenceUtility {

	private static PersistenceUtility instance;
	private EntityManagerFactory emf;
	private EntityManager em;
	
	public PersistenceUtility()
	{
		emf = Persistence.createEntityManagerFactory("$object/db/requirements.odb");
	}
	
	public static PersistenceUtility getInstance()
	{
		
		if(instance == null){
			instance = new PersistenceUtility();
		}
		instance.em = instance.emf.createEntityManager();
			return instance;
	}
	
	public void create(Requirement r)
	{
		em.getTransaction().begin();
		em.persist(r);
		em.getTransaction().commit();
		em.close();
	}
	
	
	public List  read(){
		
		return em.createQuery("SELECT r FROM Requirement r").getResultList();
			
	}
	
	public void remove(Requirement r){
		Requirement aux = em.find(Requirement.class, r);
		em.getTransaction().begin();
		em.remove(aux);
		em.getTransaction().commit();
		em.close();
		
	}

	public void uppDate(Requirement r) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.merge(r);
		em.getTransaction().commit();
		em.close();
	}
}

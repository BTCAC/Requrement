package com.btc.aclabs.Requirement.DAL;

import java.util.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.btc.aclabs.Requirement.BL.dmos.Requirement;

public class PersistanceUtility {

	private static PersistanceUtility instance;
	private EntityManagerFactory emf;
	private EntityManager em;
	
	private PersistanceUtility()
	{
		emf = Persistence.createEntityManagerFactory("$object/db/requirements.odb");
	}
	
	public static PersistanceUtility getInstance()
	{
		
		if(instance == null){
			instance = new PersistanceUtility();
		}
		instance.em = instance.emf.createEntityManager();
			return instance;
	}
	
	public void create(Requirement r)
	{
		em.getTransaction().begin();
		em.persist(r);
		em.getTransaction().commit();
		em.close();
	}
	
	public List<Requirement> getall()
	{
		return em.createQuery("SELECT r FROM Requirement r").getResultList();
	}
	
}

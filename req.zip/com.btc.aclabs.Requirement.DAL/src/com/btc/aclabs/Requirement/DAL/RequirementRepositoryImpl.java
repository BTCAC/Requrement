package com.btc.aclabs.Requirement.DAL;

import java.util.List;

import javax.inject.Inject;

import com.btc.aclabs.Requirement.BL.dmos.Requirement;
import com.btc.aclabs.Requirement.BL.service.RequirementRepository;

public class RequirementRepositoryImpl implements RequirementRepository{
	
	
	@Inject
	private PersistenceUtility persistenceUtilityService;
	
	@Override
	public void create(Requirement r) {
		persistenceUtilityService.create(r);
		
	}

	@Override
	public void remove(Requirement r) {
		persistenceUtilityService.remove(r);
	}

	@Override
	public void upppDate(Requirement r) {
		persistenceUtilityService.uppDate(r);
			}

	@Override
	public void read() {
		persistenceUtilityService.read();;
				
	}

}

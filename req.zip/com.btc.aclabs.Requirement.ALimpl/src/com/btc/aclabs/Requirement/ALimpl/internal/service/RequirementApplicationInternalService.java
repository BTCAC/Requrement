package com.btc.aclabs.Requirement.ALimpl.internal.service;

import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.btc.aclabs.Requirement.AL.dto.RequirementDto;
import com.btc.aclabs.Requirement.AL.service.RequirementApplicationService;
import com.btc.aclabs.Requirement.BL.service.RequirementService;



@Component(immediate = true)
public class RequirementApplicationInternalService  implements RequirementApplicationService {

	private RequirementService req;
	
	@Reference
	public void setR(RequirementService req1){
		this.req = req1;
	}
	@Override
	public void create(String s) {
		// TODO Auto-generated method stub
		System.out.println("se face:");
	}
	@Override
	public List<RequirementDto> getAll() {
		// TODO Auto-generated method stub
		
		return null;
	}

	
	
}

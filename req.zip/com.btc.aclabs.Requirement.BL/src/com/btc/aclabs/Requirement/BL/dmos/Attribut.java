package com.btc.aclabs.Requirement.BL.dmos;

public interface Attribut {
	 boolean equals(Object o);
	 String toString();
	 void changeDescription(String description);
	 String getType();
}

package com.btc.aclabs.Requirement.BL.dmos;

public interface Requirement {

	String toString();
	String getNameReq();
	String getShortDescriptionReq();
	String getLongDescriptionReq();
	String getCreatorReq();
}
	
package com.btc.aclabs.Requirement.BLimpl.dmos;

import com.btc.aclabs.Requirement.BL.dmos.Attribut;

public class AttributImpl implements Attribut {

	private String type;
	private String description;
	
	public AttributImpl(String type,String description){
		this.type=type;
		this.description=description;
	}
	public boolean equals(Object o){
		if(o instanceof AttributImpl && this.type==((AttributImpl)o).type)
		return true;
		else 
		return false;
	}
	public String toString(){
		return type+": "+description;
	}
	public void changeDescription(String description){
		this.description=description;
	}
	public String getType(){
		return type;
	}
	
}

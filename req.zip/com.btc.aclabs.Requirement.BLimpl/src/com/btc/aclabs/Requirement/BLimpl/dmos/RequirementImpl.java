package com.btc.aclabs.Requirement.BLimpl.dmos;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import com.btc.aclabs.Requirement.BL.dmos.Attribut;
import com.btc.aclabs.Requirement.BL.dmos.Requirement;


public class RequirementImpl implements Requirement {

	private String name;
	private String shortDescription;
	private String longDescription;
	private SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
	private Date creationDate=new Date();
	private Date modifyDate=new Date();
	private String creator;
	private ArrayList <Attribut> attributesList=new ArrayList<Attribut>();
	private ArrayList <Requirement> requirementList=new ArrayList<Requirement>();
	
	
	
	public RequirementImpl(String name,String shortDescription,String longDescription,String creationDate,String modifyDate,String creator) throws ParseException{
		this.name=name;
		this.shortDescription=shortDescription;
		this.longDescription=longDescription;
		this.creationDate = sdf.parse(creationDate);
		this.modifyDate = sdf.parse(modifyDate);
		this.creator=creator;
	}
	
	public String getNameReq() {
		// TODO Auto-generated method stub
		return this.name;
	}

	
	public String getShortDescriptionReq() {
		// TODO Auto-generated method stub
		return this.shortDescription;
	}

	@Override
	public String getLongDescriptionReq() {
		// TODO Auto-generated method stub
		return this.longDescription;
	}

	@Override
	public String getCreatorReq() {
		// TODO Auto-generated method stub
		return this.creator;
	}

}

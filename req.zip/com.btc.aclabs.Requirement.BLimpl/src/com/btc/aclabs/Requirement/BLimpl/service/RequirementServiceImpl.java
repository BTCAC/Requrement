package com.btc.aclabs.Requirement.BLimpl.service;

import java.text.ParseException;
import java.util.ArrayList;

import org.osgi.service.component.annotations.Component;

import com.btc.aclabs.Requirement.BL.dmos.Attribut;
import com.btc.aclabs.Requirement.BL.dmos.Requirement;
import com.btc.aclabs.Requirement.BL.service.RequirementService;
import com.btc.aclabs.Requirement.BLimpl.dmos.AttributImpl;
import com.btc.aclabs.Requirement.BLimpl.dmos.RequirementImpl;

@Component(immediate = true)

public class RequirementServiceImpl implements RequirementService {
	private ArrayList <Requirement> requirementList=new ArrayList<Requirement>();
	private ArrayList <Attribut> attributesList=new ArrayList<Attribut>();
		
	@Override
	public void addRequirement(Requirement r) {
		// TODO Auto-generated method stub
		requirementList.add(r);
	}

	@Override
	public void addAttributes(String type, String description) {
		// TODO Auto-generated method stub
		Attribut Att=new AttributImpl(type,description);
		boolean t=false;
		for(Attribut it:attributesList){
			if(it.equals(Att)){
				t=true;
				it.changeDescription(description);
			}
		}
		if(t==false)
		attributesList.add(Att);
	}

	@Override
	public void displayAll() {
		// TODO Auto-generated method stub
		if(requirementList.isEmpty())
			System.out.println("We don't have Requirement");
		else
		{	
			for(Requirement it:requirementList)
				System.out.println(it+"\n\n");
		}
	}

	@Override
	public void displaydetails(Object o) {
		// TODO Auto-generated method stub
		if(o instanceof Requirement)
			System.out.println(((Requirement)o));
	}

	@Override
	public Requirement createNew(String name, String shortDescription, String longDescription, String creationDate,
			String modifyDate, String creator) throws ParseException {

		Requirement req=new RequirementImpl(name,shortDescription,longDescription,creationDate,modifyDate,creator);
		requirementList.add(req);
		return req;
	}

	}
	



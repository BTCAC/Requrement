package com.btc.ac.labs.project.requirement.handlers;

import org.eclipse.e4.core.di.annotations.Execute;

public class ImportXML {
@Execute
	
	public void execute(){
		System.out.println((this.getClass().getSimpleName() + " called"));
	}
}

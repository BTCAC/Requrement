package com.btc.ac.labs.project.requirement.parts;

import javax.annotation.PostConstruct;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;


public class Operations {
	private Text text;
	private Display display;
	
	@PostConstruct
	
	public void createOper( Composite parent){
		
	/*	 TENTATIVA DE MENIU :(
	 * parent.setLayout(new GridLayout(2, false));
	 

        // text = new Text(parent, SWT.BORDER);
         
         Label labelName = new Label(parent, SWT.NONE);
 		labelName.setText("Name: ");
 		Text textName = new Text(parent, SWT.BORDER);
 		
 		Label labelsDescription = new Label(parent, SWT.NONE);
 		labelsDescription.setText("Long Description: ");
 				Text TshortDescription = new Text(parent, SWT.BORDER);
 		
 		Label labellDescription = new Label(parent, SWT.NONE);
 		labellDescription.setText("Long Description: ");
 		Text TlongDescription = new Text(parent, SWT.BORDER);
 		
 		Label lCreator = new Label(parent, SWT.NONE);
 		lCreator.setText("Creator: ");
 		Text Tcreator = new Text(parent, SWT.BORDER);
 		
 		Label lcreationDate= new Label(parent, SWT.NONE);
 		lcreationDate.setText("Description: ");
 		Text TcreationDate = new Text(parent, SWT.BORDER);
 		
 		Label modiDate = new Label(parent, SWT.NONE);
 		modiDate.setText("Description: ");
 		Text TmodifyDate = new Text(parent, SWT.BORDER);
 		
 	
 		
 		
 		 final Tree tree = new Tree(parent, SWT.V_SCROLL);
        // for (int i = 1; i < 5; i++) {
             TreeItem item = new TreeItem(tree, SWT.NONE);
             item.setText("Create new Req");
           //  for (int j = 0; j < 4; j++) {
                 TreeItem subItem = new TreeItem(item, SWT.NONE);
                 subItem.setText("Display one");
                // subItem.setText(String.valueOf(i) + " " + String.valueOf(j));
            // }
        // }
         tree.pack();
         Menu menu = new Menu(tree);
         MenuItem menuItem = new MenuItem(menu, SWT.NONE);
         menuItem.setText("Print Element");
         menuItem.addSelectionListener(new SelectionAdapter() {
        	 
        	 public void widgetSelected(SelectionEvent event) {
                 System.out.println(tree.getSelection()[1].getText());
             }
         });
	
         tree.setMenu(menu);
         parent.pack();
         //parent.open();
         while (!parent.isDisposed()) {
             if (!display.readAndDispatch()) {
                 display.sleep();
             }
         }
 		
	}}
	
	
	//table 	
	
	 Shell shell = new Shell(display);

     shell.setLayout(new GridLayout());


     Table table = new Table(shell, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION);
     table.setLinesVisible(true);
     table.setHeaderVisible(true);
     GridData data = new GridData(SWT.FILL, SWT.FILL, true, true);
     data.heightHint = 200;
     table.setLayoutData(data);

     String[] titles = { "First Name", "Last Name", "Age" };
     for (int i = 0; i < titles.length; i++) {
         TableColumn column = new TableColumn(table, SWT.NONE);
         column.setText(titles[i]);
         table.getColumn(i).pack();
     }

     for (int i = 0 ; i<= 50 ; i++){
         TableItem item = new TableItem(table, SWT.NONE);
         item.setText (0, "Person " +i );
         item.setText (1, "LastName " +i );
         item.setText (2, String.valueOf(i));
     }

     for (int i=0; i<titles.length; i++) {
         table.getColumn (i).pack ();
     }
     shell.pack ();
     shell.open ();

     shell.open();
     while (!shell.isDisposed()) {
         if (!display.readAndDispatch()) {
             display.sleep();
         }  /*/
		
		
	// CALENDAR PT UTILIZATOR	
		  final Shell shell = new Shell(display);
	        shell.setLayout(new RowLayout());
	        
	       // NU MERGE ->Color color1 = new Color(display,null, 290);
	    	
	        // initialize a parent composite with a grid layout manager

	        GridLayout gridLayout = new GridLayout();
	        gridLayout.numColumns = 1;
	        parent.setLayout(gridLayout);
	        DateTime calendar = new DateTime(parent, SWT.CALENDAR);
	        DateTime time = new DateTime(parent, SWT.TIME);


	        shell.pack();
	        
	        Button b1 = new Button(parent,SWT.PUSH);
	        b1.setText("Create new Req");
	        
	        b1.addSelectionListener(new SelectionListener() {
				
				@Override
				public void widgetSelected(SelectionEvent e) {
					// TODO Auto-generated method stub
					
					// CUMVA TREBUIE facuta actiune apt a face legatura catre playground
				}
				
				@Override
				public void widgetDefaultSelected(SelectionEvent e) {
					// TODO Auto-generated method stub
					
				}
			});
	       
	        while (!shell.isDisposed()) {
	            if (!display.readAndDispatch())
	                display.sleep();
	        }
		
     }}
 
	
	
    




package com.btc.ac.labs.project.requirement.parts;

public class Overview {

	public Overview() {
		System.out.println("it workes" );
		
	}
}

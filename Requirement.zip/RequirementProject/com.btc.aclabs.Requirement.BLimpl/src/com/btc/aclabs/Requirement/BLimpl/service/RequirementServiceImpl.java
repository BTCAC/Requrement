package com.btc.aclabs.Requirement.BLimpl.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.btc.aclabs.Requirement.BL.dmos.Attribut;
import com.btc.aclabs.Requirement.BL.dmos.RequirementDMO;
import com.btc.aclabs.Requirement.BL.service.RequirementRepository;
import com.btc.aclabs.Requirement.BL.service.RequirementService;
import com.btc.aclabs.Requirement.BLimpl.dmos.AttributImpl;
import com.btc.aclabs.Requirement.BLimpl.dmos.RequirementDMOImpl;

@Component(immediate = true)

public class RequirementServiceImpl implements RequirementService {

	private RequirementRepository repo;

	private ArrayList<RequirementDMO> requirementList = new ArrayList<RequirementDMO>();
	private ArrayList<Attribut> attributesList = new ArrayList<Attribut>();

	public void addRequirement(RequirementDMO r) {
		requirementList.add(r);
	}

	public String toString() {
		String s = "";
		for (RequirementDMO req : requirementList) {
			s += req.getName() + " " + req.getShortDescription() + " " + req.getLongDescription() + " "
					+ req.getCreator() + " " + req.getCreationDate() + " " + req.getModifyDate() + "\n";
		}
		return s;
	}

	public void addAttributes(String type, String description) {

		Attribut Att = new AttributImpl(type, description);
		boolean t = false;
		for (Attribut it : attributesList) {
			if (it.equals(Att)) {
				t = true;
				it.changeDescription(description);
			}
		}
		if (t == false)
			attributesList.add(Att);
	}

	public void displayAll() {

		if (requirementList.isEmpty())
			System.out.println("We don't have Requirement");
		else {
			for (RequirementDMO it : requirementList)
				System.out.println(it + "\n\n");
		}
	}

	public void displaydetails(Object o) {

		if (o instanceof RequirementDMO)
			System.out.println(((RequirementDMO) o));
	}

	public void create(String name, String shortDescription, String longDescription, String creationDate,
			String modifyDate,String creator) throws ParseException {

		RequirementDMO req = repo.createDMO(name, shortDescription, longDescription, creationDate, modifyDate,creator);
		/*requirementList.add(req);*/

		repo.create(req);

	}

	@Reference
	public void setRequirementRepositoryService(RequirementRepository requirementRepositoryService) {
		this.repo = requirementRepositoryService;
	}

	@Override
	public List<RequirementDMO> getAll() {
		return this.repo.getAll();
	}
}

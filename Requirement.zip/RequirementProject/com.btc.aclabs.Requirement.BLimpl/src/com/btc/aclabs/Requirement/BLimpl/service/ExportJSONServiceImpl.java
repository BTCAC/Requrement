package com.btc.aclabs.Requirement.BLimpl.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.btc.aclabs.Requirement.BL.dmos.RequirementDMO;
import com.btc.aclabs.Requirement.BL.service.ExportJSONService;

public class ExportJSONServiceImpl implements ExportJSONService {

	private ArrayList<RequirementDMO> requirement;

	public ExportJSONServiceImpl(ArrayList<RequirementDMO> requirement) {
		this.requirement = requirement;
	}
	/**
	 * @param path this method takes the whole path including the file name to be exported to
	 * */
	@SuppressWarnings("unchecked")
	public void exportJSON(String path) {
		try {
			FileOutputStream fos = new FileOutputStream(path);
			OutputStreamWriter osw = new OutputStreamWriter(fos);
			PrintWriter ow = new PrintWriter(osw);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
			JSONArray reqarray=new JSONArray();
			for (RequirementDMO req : requirement) {
				JSONObject reqobject = new JSONObject();
				/*JSONArray atribut = new JSONArray();
				for (Attribut at : req.getAttributeList()) {
					JSONObject atr = new JSONObject();
					atr.put("type", at.getType());
					atr.put("description", at.getDescription());
					atribut.add(atr);
				}
				reqobject.put("attributes", atribut);*/
				reqobject.put("creator", req.getCreator());
				reqobject.put("modifyDate", sdf.format(req.getModifyDate()));
				reqobject.put("creationDate", sdf.format(req.getCreationDate()));
				reqobject.put("longDescription", req.getLongDescription());
				reqobject.put("shortDescription", req.getShortDescription());
				reqobject.put("name", req.getName());
				reqarray.add(reqobject);
			}
			JSONArray.writeJSONString(reqarray, ow);
			ow.close();
		} catch (IOException e) {
			// ignore
		}
	}
}
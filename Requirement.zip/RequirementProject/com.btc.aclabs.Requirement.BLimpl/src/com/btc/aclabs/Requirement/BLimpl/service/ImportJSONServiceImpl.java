package com.btc.aclabs.Requirement.BLimpl.service;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.btc.aclabs.Requirement.BL.dmos.RequirementDMO;
import com.btc.aclabs.Requirement.BL.service.ImportJSONService;
import com.btc.aclabs.Requirement.BLimpl.dmos.RequirementDMOImpl;

public class ImportJSONServiceImpl implements ImportJSONService{

	@SuppressWarnings("unchecked")
	public void ImportJSON(String path) {
		ArrayList<RequirementDMO> reqlist=new ArrayList<RequirementDMO>();
		JSONParser parser=new JSONParser();
		try
		{
			FileReader fr=new FileReader(path);
			JSONArray jsonarr=(JSONArray)parser.parse(fr);
			Iterator<JSONObject> iterator=(Iterator<JSONObject>) jsonarr.iterator();
			while(iterator.hasNext())
			{
				JSONObject jsonobj=new JSONObject();
				jsonobj=iterator.next();
				String name=(String)jsonobj.get("name");
				String shortdes=(String)jsonobj.get("shortDescription");
				String longdes=(String)jsonobj.get("longDescription");
				String crdate=(String)jsonobj.get("creationDate");
				String moddate=(String)jsonobj.get("modifyDate");
				String creator=(String)jsonobj.get("creator");
				//ArrayList <Attribut> attribut=(ArrayList <Attribut>)jsonobj.get("attributes");
				RequirementDMO req=new RequirementDMOImpl(name,shortdes,longdes,crdate,moddate,creator);
				reqlist.add(req);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		//add reqlist to bd
	}

}

package com.btc.aclabs.Requirement.ALimpl.internal.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.btc.aclabs.Requirement.AL.dto.RequirementDto;
import com.btc.aclabs.Requirement.AL.service.RequirementApplicationService;
import com.btc.aclabs.Requirement.ALimpl.internal.dto.RequirementInternalDto;
import com.btc.aclabs.Requirement.BL.dmos.RequirementDMO;
import com.btc.aclabs.Requirement.BL.service.ExportJSONService;
import com.btc.aclabs.Requirement.BL.service.ImportJSONService;
import com.btc.aclabs.Requirement.BL.service.RequirementService;

@Component(immediate = true)
public class RequirementApplicationServiceImpl implements RequirementApplicationService {

	private RequirementService requirementService;
	private ExportJSONService exportJSON;
	private ImportJSONService importJSON;

	@Reference
	public void setR(RequirementService req1) {
		requirementService = req1;
	}
	
	public void setJSONExport(ExportJSONService ejs)
	{
		exportJSON=ejs;
	}
	
	public void setJSONImport(ImportJSONService ijs)
	{
		importJSON=ijs;
	}
	
	
	/*
	 * public List<RequirementDto> getAll() {
	 * 
	 * req.displayAll(); return null; }
	 */

	public String toString() {
		return requirementService.toString();
	}

	@Override
	public List<RequirementDto> getAll() {
		List<RequirementDto> reqDTOs = new ArrayList<RequirementDto>();
		for (RequirementDMO reqDMO : requirementService.getAll()) {
				RequirementDto reqDTO= createDTO(reqDMO.getName(), reqDMO.getShortDescription(),
						reqDMO.getLongDescription(), reqDMO.getCreationDate(), reqDMO.getModifyDate(), reqDMO.getCreator());
				reqDTOs.add(reqDTO);
		}
		return reqDTOs;
	}

	@Override
	public void create(String name, String shortDescription, String longDescription, String creationDate,
			String modifyDate,String creator) throws ParseException {
		requirementService.create(name, shortDescription, longDescription, creationDate, modifyDate,creator);
		System.out.print("done");

		
	}

	@Override
	public RequirementDto createDTO(String name, String shortDescription, String longDescription, String creationDate,
			String modifyDate, String creator) {
		try {
			return new RequirementInternalDto(name, shortDescription, longDescription, creationDate, modifyDate, creator);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	
	 public void ExportJson(String path) {
		 exportJSON.exportJSON(path);
	 }
	 
	 public void ImportJson(String path) {
		 importJSON.ImportJSON(path);
	 }

}

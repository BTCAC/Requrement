package com.btc.aclabs.Requirement.DAL;

import java.util.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.osgi.service.component.annotations.Component;

@Component(immediate = true)
public class PersistenceUtilityImpl implements PersistenceUtility {

	private static PersistenceUtilityImpl instance;
	private EntityManagerFactory emf;
	private EntityManager em;

	public PersistenceUtilityImpl() {
		emf = Persistence.createEntityManagerFactory("$objectdb/db/requirements.odb");
	}

	public static PersistenceUtilityImpl getInstance() {

		if (instance == null) {
			instance = new PersistenceUtilityImpl();
		}
		return instance;
	}

	@Override
	public void create(Requirement r) {
		em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(r);
		em.getTransaction().commit();
		em.close();
	}

	/*@Override
	public List read() {

		return em.createQuery("SELECT r FROM Requirement r").getResultList();

	}*/

	@Override
	public void remove(Requirement r) {
		em = emf.createEntityManager();
		Requirement aux = em.find(Requirement.class, r);
		em.getTransaction().begin();
		em.remove(aux);
		em.getTransaction().commit();
		em.close();

	}

	@Override
	public void update(Requirement r) {
		// TODO Auto-generated method stub
		em = emf.createEntityManager();
		em.getTransaction().begin();
		em.merge(r);
		em.getTransaction().commit();
		em.close();
	}

	@Override
	public List<Requirement> getAll() {
		em = emf.createEntityManager();
		List<Requirement> result = em.createQuery("SELECT r FROM com.btc.aclabs.Requirement.DAL.RequirementImpl r").getResultList();
		em.close();
		
		return result;
	}

	@Override
	public Requirement getRequirementByID(int id) {
		em = emf.createEntityManager();
		Requirement result = (Requirement) em.createQuery("SELECT r FROM com.btc.aclabs.Requirement.DAL.RequirementImpl r WHERE r.id =:id").getSingleResult();
		em.close();
		
		return result;
	}
}

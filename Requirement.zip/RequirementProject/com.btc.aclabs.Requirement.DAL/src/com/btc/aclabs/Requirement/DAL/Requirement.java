package com.btc.aclabs.Requirement.DAL;

import java.util.ArrayList;
import java.util.Date;

import com.btc.aclabs.Requirement.BL.dmos.Attribut;

public interface Requirement {

	String toString();

	String getNameReq();

	String getShortDescriptionReq();

	String getLongDescriptionReq();

	String getCreatorReq();

	ArrayList<Attribut> getAttributeList();

	Date getModifyDate();

	Date getCreationDate();

	public int getID();

}

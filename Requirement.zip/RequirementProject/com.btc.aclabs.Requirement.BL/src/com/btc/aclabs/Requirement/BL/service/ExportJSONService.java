package com.btc.aclabs.Requirement.BL.service;

public interface ExportJSONService {
	void exportJSON(String path);
}
